import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { GetCurrentUser } from '@/lib/auth'
import { ValidateForestName } from '@/lib/validators'

export async function POST(request: Request) {
  const user = await GetCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
  }

  const { name } = await request.json()
  const validation = ValidateForestName(name)
  if (!validation.valid) {
    return NextResponse.json({ error: validation.error }, { status: 400 })
  }

  try {
    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { forestName: name.trim() },
    })

    await prisma.action.create({
      data: {
        senderId: user.id,
        receiverId: user.id,
        type: 'RENAME_FOREST',
        amount: 0,
      },
    })

    const { BroadcastUpdate } = await import('@/lib/realtime')
    BroadcastUpdate({
      type: 'renamed',
      userId: user.id,
      forestName: updated.forestName,
    })

    return NextResponse.json({ success: true, forestName: updated.forestName })
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'هذا الاسم مستخدم بالفعل، اختر اسماً آخر' }, { status: 409 })
    }
    return NextResponse.json({ error: 'خطأ في حفظ الاسم' }, { status: 500 })
  }
}
