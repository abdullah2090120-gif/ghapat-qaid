'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Toast from '@/components/Toast'
import RenameForestModal from '@/components/RenameForestModal'
import { TempColor } from '@/lib/utils'
import { useStore } from '@/store/useStore'

interface UserRow {
  id: string
  displayName: string
  forestName: string | null
  accessToken: string
  temperature: number
  coldPoints: number
  hotPoints: number
  isBanned: boolean
  lastSeenAt: string
  online: boolean
}

interface Stats {
  onlineCount: number
  maxTemp: number
  minTemp: number
  avgTemp: number
  totalUsers: number
}

export default function HostPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const showToast = useStore((s) => s.showToast)

  const [loading, setLoading] = useState(true)
  const [authorized, setAuthorized] = useState(false)
  const [users, setUsers] = useState<UserRow[]>([])
  const [stats, setStats] = useState<Stats | null>(null)
  const [showGrantModal, setShowGrantModal] = useState(false)
  const [grantTarget, setGrantTarget] = useState<UserRow | null>(null)
  const [grantType, setGrantType] = useState<'COLD' | 'HOT'>('HOT')
  const [grantAmount, setGrantAmount] = useState<0.5 | 1>(1)
  const [renameTarget, setRenameTarget] = useState<UserRow | null>(null)
  const [showRenameModal, setShowRenameModal] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)

  const origin = typeof window !== 'undefined' ? window.location.origin : ''

  const checkAuth = useCallback(async () => {
    const key = searchParams.get('key')
    try {
      const res = await fetch('/api/host/auth' + (key ? `?key=${key}` : ''), {
        method: 'GET',
      })
      if (res.ok) {
        setAuthorized(true)
        loadData()
      } else {
        router.replace('/')
      }
    } catch {
      router.replace('/')
    } finally {
      setLoading(false)
    }
  }, [searchParams, router])

  const loadData = useCallback(async () => {
    try {
      const [usersRes, statsRes] = await Promise.all([
        fetch('/api/host/users'),
        fetch('/api/host/stats'),
      ])
      if (usersRes.ok) {
        const data = await usersRes.json()
        setUsers(data.users)
      }
      if (statsRes.ok) {
        const data = await statsRes.json()
        setStats(data.stats)
      }
    } catch (e) {
      console.error(e)
    }
  }, [])

  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  // تحديث كل 5 ثوانٍ
  useEffect(() => {
    if (!authorized) return
    const interval = setInterval(loadData, 5000)
    return () => clearInterval(interval)
  }, [authorized, loadData])

  const generateUsers = async () => {
    if (!confirm('هل أنت متأكد من توليد 22 مستخدم جديد؟')) return
    try {
      const res = await fetch('/api/host/generate-users', { method: 'POST' })
      const data = await res.json()
      if (res.ok) {
        showToast('تم توليد 22 غابة بنجاح! 🎉', 'success')
        loadData()
      } else {
        showToast(data.error || 'حدث خطأ', 'error')
      }
    } catch {
      showToast('حدث خطأ', 'error')
    }
  }

  const copyLink = async (user: UserRow) => {
    const link = `${origin}/u/${user.accessToken}`
    try {
      await navigator.clipboard.writeText(link)
      setCopiedId(user.id)
      setTimeout(() => setCopiedId(null), 2000)
      showToast('تم نسخ الرابط ✅', 'success')
    } catch {
      prompt('انسخ هذا الرابط:', link)
    }
  }

  const copyAllLinks = async () => {
    const links = users.map((u) => `${u.displayName}: ${origin}/u/${u.accessToken}`).join('\n')
    try {
      await navigator.clipboard.writeText(links)
      showToast('تم نسخ جميع الروابط ✅', 'success')
    } catch {
      prompt('انسخ هذه الروابط:', links)
    }
  }

  const grantPoints = async () => {
    if (!grantTarget) return
    try {
      const res = await fetch('/api/host/grant-points', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: grantTarget.id,
          type: grantType,
          amount: grantAmount,
        }),
      })
      const data = await res.json()
      if (res.ok) {
        showToast(`تم منح ${grantAmount} نقاط ${grantType === 'COLD' ? 'باردة ❄️' : 'ساخنة 🔥'}`, 'success')
        setShowGrantModal(false)
        loadData()
      } else {
        showToast(data.error || 'خطأ', 'error')
      }
    } catch {
      showToast('خطأ', 'error')
    }
  }

  const resetToken = async (user: UserRow) => {
    if (!confirm(`إعادة توليد رابط ${user.displayName}؟ الرابط القديم سيتوقف عن العمل.`)) return
    try {
      const res = await fetch(`/api/host/users/${user.id}/reset-token`, { method: 'POST' })
      if (res.ok) {
        showToast('تم توليد رابط جديد ✅', 'success')
        loadData()
      }
    } catch {}
  }

  const toggleBan = async (user: UserRow) => {
    const action = user.isBanned ? 'إلغاء الحظر' : 'حظر'
    if (!confirm(`${action} ${user.displayName}؟`)) return
    try {
      const res = await fetch(`/api/host/users/${user.id}/ban`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ banned: !user.isBanned }),
      })
      if (res.ok) {
        showToast(user.isBanned ? 'تم إلغاء الحظر ✅' : 'تم الحظر 🚫', 'info')
        loadData()
      }
    } catch {}
  }

  const resetAll = async () => {
    if (!confirm('إعادة ضبط جميع الغابات إلى 32°C؟')) return
    try {
      const res = await fetch('/api/host/reset-all', { method: 'POST' })
      if (res.ok) {
        showToast('تم إعادة الضبط 🔄', 'success')
        loadData()
      }
    } catch {}
  }

  const handleHostRename = async (name: string) => {
    if (!renameTarget) return
    const res = await fetch(`/api/host/users/${renameTarget.id}/rename`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })
    if (!res.ok) {
      const data = await res.json().catch(() => ({}))
      throw new Error(data.error || 'خطأ')
    }
    showToast('تم إعادة التسمية ✅', 'success')
    setShowRenameModal(false)
    loadData()
  }

  if (loading) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-5xl mb-4 animate-pulse">🔐</div>
        <p className="text-emerald-300">جارٍ التحقق من الهوية...</p>
      </main>
    )
  }

  if (!authorized) return null

  return (
    <main className="min-h-screen px-4 py-6 max-w-7xl mx-auto">
      <Toast />

      {/* الرأس */}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-emerald-300">🎛️ لوحة تحكم المضيف</h1>
          <p className="text-emerald-400/60 text-sm">غابة قائدة — التحكم الكامل</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            onClick={generateUsers}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold transition btn-press text-sm"
          >
            🌲 توليد الغابات (22)
          </button>
          <button
            onClick={copyAllLinks}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg font-bold transition btn-press text-sm"
          >
            📋 نسخ كل الروابط
          </button>
          <button
            onClick={resetAll}
            className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-bold transition btn-press text-sm"
          >
            🔄 إعادة الضبط
          </button>
        </div>
      </div>

      {/* الإحصائيات */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <div className="bg-emerald-950/60 border border-emerald-800/40 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-emerald-300">{stats.onlineCount}/{stats.totalUsers}</p>
            <p className="text-xs text-emerald-400/60 mt-1">متصل الآن</p>
          </div>
          <div className="bg-red-950/40 border border-red-800/40 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-red-300">{stats.maxTemp.toFixed(1)}°</p>
            <p className="text-xs text-red-400/60 mt-1">أعلى حرارة</p>
          </div>
          <div className="bg-cyan-950/40 border border-cyan-800/40 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-cyan-300">{stats.minTemp.toFixed(1)}°</p>
            <p className="text-xs text-cyan-400/60 mt-1">أدنى حرارة</p>
          </div>
          <div className="bg-amber-950/40 border border-amber-800/40 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-amber-300">{stats.avgTemp.toFixed(1)}°</p>
            <p className="text-xs text-amber-400/60 mt-1">متوسط الحرارة</p>
          </div>
        </div>
      )}

      {/* جدول المستخدمين */}
      <div className="bg-emerald-950/40 border border-emerald-800/30 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-emerald-900/50 text-emerald-300 text-xs">
                <th className="px-3 py-3 text-right">#</th>
                <th className="px-3 py-3 text-right">اسم الغابة</th>
                <th className="px-3 py-3 text-right">المالك</th>
                <th className="px-3 py-3 text-right">الحرارة</th>
                <th className="px-3 py-3 text-right">النقاط</th>
                <th className="px-3 py-3 text-right">الحالة</th>
                <th className="px-3 py-3 text-right">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {users.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-emerald-400/50">
                    لا يوجد مستخدمون بعد — اضغط "توليد الغابات" للبدء
                  </td>
                </tr>
              )}
              {users.map((u, i) => (
                <tr key={u.id} className="border-t border-emerald-900/30 hover:bg-emerald-900/20">
                  <td className="px-3 py-3 text-emerald-500/60">{i + 1}</td>
                  <td className="px-3 py-3 font-bold text-white max-w-[120px] truncate">
                    {u.forestName || '—'}
                    <button
                      onClick={() => { setRenameTarget(u); setShowRenameModal(true) }}
                      className="mr-2 text-xs text-emerald-400 hover:text-emerald-300"
                    >✏️</button>
                  </td>
                  <td className="px-3 py-3 text-emerald-200/80">{u.displayName}</td>
                  <td className={`px-3 py-3 font-bold ${TempColor(u.temperature)}`}>
                    {u.temperature.toFixed(1)}°
                  </td>
                  <td className="px-3 py-3 text-xs">
                    <span className="text-cyan-300">❄️ {u.coldPoints}</span>
                    <span className="mx-1 text-emerald-700">|</span>
                    <span className="text-orange-300">🔥 {u.hotPoints}</span>
                  </td>
                  <td className="px-3 py-3">
                    {u.isBanned ? (
                      <span className="text-red-400 text-xs">🚫 محظور</span>
                    ) : u.online ? (
                      <span className="text-green-400 text-xs">● متصل</span>
                    ) : (
                      <span className="text-gray-500 text-xs">○ غير متصل</span>
                    )}
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex gap-1 flex-wrap">
                      <button
                        onClick={() => copyLink(u)}
                        className="px-2 py-1 bg-blue-700/60 hover:bg-blue-600 text-white rounded text-xs btn-press"
                      >
                        {copiedId === u.id ? '✓' : '🔗'}
                      </button>
                      <button
                        onClick={() => { setGrantTarget(u); setShowGrantModal(true) }}
                        className="px-2 py-1 bg-purple-700/60 hover:bg-purple-600 text-white rounded text-xs btn-press"
                      >
                        🎁
                      </button>
                      <button
                        onClick={() => resetToken(u)}
                        className="px-2 py-1 bg-amber-700/60 hover:bg-amber-600 text-white rounded text-xs btn-press"
                        title="إعادة توليد الرابط"
                      >
                        🔄
                      </button>
                      <button
                        onClick={() => toggleBan(u)}
                        className={`px-2 py-1 rounded text-xs btn-press ${
                          u.isBanned
                            ? 'bg-green-700/60 hover:bg-green-600 text-white'
                            : 'bg-red-700/60 hover:bg-red-600 text-white'
                        }`}
                      >
                        {u.isBanned ? '✓' : '🚫'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* نافذة منح النقاط */}
      {showGrantModal && grantTarget && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-gradient-to-b from-emerald-900 to-green-950 p-6 rounded-2xl shadow-2xl max-w-sm w-full border border-emerald-700/50">
            <h2 className="text-xl font-bold text-white mb-4 text-center">
              🎁 منح نقاط لـ {grantTarget.displayName}
            </h2>

            <div className="mb-4">
              <p className="text-sm text-emerald-300 mb-2">نوع النقاط:</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setGrantType('COLD')}
                  className={`py-3 rounded-xl font-bold transition btn-press ${
                    grantType === 'COLD'
                      ? 'bg-cyan-600 text-white ring-2 ring-cyan-400'
                      : 'bg-cyan-950/50 text-cyan-300 border border-cyan-800/40'
                  }`}
                >
                  ❄️ باردة
                </button>
                <button
                  onClick={() => setGrantType('HOT')}
                  className={`py-3 rounded-xl font-bold transition btn-press ${
                    grantType === 'HOT'
                      ? 'bg-orange-600 text-white ring-2 ring-orange-400'
                      : 'bg-orange-950/50 text-orange-300 border border-orange-800/40'
                  }`}
                >
                  🔥 ساخنة
                </button>
              </div>
            </div>

            <div className="mb-6">
              <p className="text-sm text-emerald-300 mb-2">الكمية:</p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setGrantAmount(0.5)}
                  className={`py-3 rounded-xl font-bold transition btn-press ${
                    grantAmount === 0.5
                      ? 'bg-emerald-600 text-white ring-2 ring-emerald-400'
                      : 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                  }`}
                >
                  نصف درجة (0.5)
                </button>
                <button
                  onClick={() => setGrantAmount(1)}
                  className={`py-3 rounded-xl font-bold transition btn-press ${
                    grantAmount === 1
                      ? 'bg-emerald-600 text-white ring-2 ring-emerald-400'
                      : 'bg-emerald-950/50 text-emerald-300 border border-emerald-800/40'
                  }`}
                >
                  درجة كاملة (1)
                </button>
              </div>
              <p className="text-xs text-emerald-400/50 mt-2 text-center">
                كل 0.5 درجة = نقطة واحدة ({grantAmount * 2} نقاط)
              </p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => setShowGrantModal(false)}
                className="flex-1 py-3 rounded-xl bg-gray-700/60 text-white hover:bg-gray-600/60 transition btn-press"
              >
                إلغاء
              </button>
              <button
                onClick={grantPoints}
                className="flex-1 py-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition btn-press"
              >
                منح 🎁
              </button>
            </div>
          </div>
        </div>
      )}

      {/* نافذة إعادة التسمية من قبل المضيف */}
      {renameTarget && (
        <RenameForestModal
          isOpen={showRenameModal}
          onClose={() => setShowRenameModal(false)}
          onSave={handleHostRename}
          initialName={renameTarget.forestName || ''}
          isFirstTime={false}
        />
      )}
    </main>
  )
}
