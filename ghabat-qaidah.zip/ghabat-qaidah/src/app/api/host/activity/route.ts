import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function GET(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const actions = await prisma.action.findMany({
    include: {
      sender: { select: { displayName: true, forestName: true } },
      receiver: { select: { displayName: true, forestName: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })

  const activities = actions.map((a) => {
    const senderName = a.sender.forestName || a.sender.displayName
    const receiverName = a.receiver.forestName || a.receiver.displayName
    let message = ''
    if (a.type === 'COLD') message = `${senderName} ❄️→ ${receiverName} (-${a.amount}°)`
    else if (a.type === 'HOT') message = `${senderName} 🔥→ ${receiverName} (+${a.amount}°)`
    else if (a.type === 'HOST_GRANT') message = `المضيف 🎁→ ${receiverName} (${a.amount}° ${a.type === 'COLD' ? 'بارد' : 'ساخن'})`
    else if (a.type === 'RENAME_FOREST') message = `${senderName} غيّر اسم غابته ✨`

    return {
      id: a.id,
      message,
      time: new Date(a.createdAt).toLocaleString('ar-SA'),
    }
  })

  return NextResponse.json({ activities })
}
