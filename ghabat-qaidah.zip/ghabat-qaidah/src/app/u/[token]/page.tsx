'use client'

import { useState, useEffect, useCallback } from 'react'
import { useParams, useRouter } from 'next/navigation'
import RenameForestModal from '@/components/RenameForestModal'
import ForestCard from '@/components/ForestCard'
import UserSidebar from '@/components/UserSidebar'
import Toast from '@/components/Toast'
import { SubscribeToForestUpdates, type ForestUpdateEvent } from '@/lib/realtime'
import { useStore } from '@/store/useStore'
import { TempColor } from '@/lib/utils'

interface Forest {
  id: string
  displayName: string
  forestName: string | null
  temperature: number
  coldPoints: number
  hotPoints: number
}

export default function UserPage() {
  const params = useParams()
  const router = useRouter()
  const token = params.token as string

  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<Forest | null>(null)
  const [forests, setForests] = useState<Forest[]>([])
  const [showRenameModal, setShowRenameModal] = useState(false)
  const [isFirstTime, setIsFirstTime] = useState(false)

  const showToast = useStore((s) => s.showToast)
  const applyEvent = useStore((s) => s.applyEvent)

  const loadForests = useCallback(async () => {
    try {
      const res = await fetch('/api/user/forests')
      if (res.ok) {
        const data = await res.json()
        setForests(data.forests)
      }
    } catch (e) {
      console.error('فشل تحميل الغابات:', e)
    }
  }, [])

  const authenticate = useCallback(async () => {
    try {
      const res = await fetch('/api/user/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token }),
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        if (data.code === 'BANNED') {
          router.replace('/banned')
        } else {
          router.replace('/invalid-link')
        }
        return
      }

      const data = await res.json()
      setUser(data.user)

      // أول دخول — اسم الغابة فارغ
      if (!data.user.forestName) {
        setIsFirstTime(true)
        setShowRenameModal(true)
      }

      loadForests()
    } catch {
      router.replace('/invalid-link')
    } finally {
      setLoading(false)
    }
  }, [token, router, loadForests])

  useEffect(() => {
    authenticate()
  }, [authenticate])

  // الاشتراك في التحديثات اللحظية
  useEffect(() => {
    const cleanup = SubscribeToForestUpdates((event: ForestUpdateEvent) => {
      if (event.type === 'reset_all') {
        setForests((prev) => prev.map((f) => ({ ...f, temperature: 32 })))
        setUser((prev) => (prev ? { ...prev, temperature: 32 } : null))
        showToast('تم إعادة ضبط جميع الغابات إلى 32°C', 'info')
        return
      }

      if (!event.userId) return

      setForests((prev) =>
        prev.map((f) => {
          if (f.id !== event.userId) return f
          return {
            ...f,
            ...(event.temperature !== undefined && { temperature: event.temperature }),
            ...(event.forestName !== undefined && { forestName: event.forestName }),
            ...(event.coldPoints !== undefined && { coldPoints: event.coldPoints }),
            ...(event.hotPoints !== undefined && { hotPoints: event.hotPoints }),
          }
        })
      )

      setUser((prev) => {
        if (!prev || prev.id !== event.userId) return prev
        return {
          ...prev,
          ...(event.temperature !== undefined && { temperature: event.temperature }),
          ...(event.forestName !== undefined && { forestName: event.forestName }),
          ...(event.coldPoints !== undefined && { coldPoints: event.coldPoints }),
          ...(event.hotPoints !== undefined && { hotPoints: event.hotPoints }),
        }
      })

      if (event.type === 'temperature_updated') {
        showToast('تحديث جديد في درجة الحرارة 🌡️', 'success')
      } else if (event.type === 'renamed') {
        showToast('تم تغيير اسم إحدى الغابات ✨', 'info')
      } else if (event.type === 'points_updated') {
        // تحديث الرصيد — إعادة التحميل
        fetch('/api/user/me')
          .then((r) => r.json())
          .then((d) => {
            if (d.user) {
              setUser((prev) =>
                prev
                  ? { ...prev, coldPoints: d.user.coldPoints, hotPoints: d.user.hotPoints }
                  : prev
              )
            }
          })
          .catch(() => {})
      }
    })

    return cleanup
  }, [showToast])

  const handleRename = async (name: string) => {
    const res = await fetch('/api/user/rename', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })

    if (!res.ok) {
      const data = await res.json().catch(() => ({}))
      throw new Error(data.error || 'حدث خطأ')
    }

    const data = await res.json()
    setUser((prev) => (prev ? { ...prev, forestName: data.forestName } : null))
    setIsFirstTime(false)
    showToast('تم تسمية غابتك بنجاح 🌲', 'success')
  }

  const handleApplyPoints = async (
    targetUserId: string,
    type: 'COLD' | 'HOT',
    amount: number
  ) => {
    const res = await fetch('/api/user/apply-points', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetUserId, type, amount }),
    })

    if (!res.ok) {
      const data = await res.json().catch(() => ({}))
      showToast(data.error || 'حدث خطأ', 'error')
      return
    }

    // تحديث الرصيد محلياً
    const pointsUsed = Math.floor(amount * 2)
    setUser((prev) => {
      if (!prev) return prev
      if (type === 'COLD') return { ...prev, coldPoints: prev.coldPoints - pointsUsed }
      return { ...prev, hotPoints: prev.hotPoints - pointsUsed }
    })
  }

  if (loading) {
    return (
      <main className="min-h-screen flex flex-col items-center justify-center">
        <div className="text-6xl mb-4 animate-pulse">🌲</div>
        <p className="text-emerald-300 text-lg">جارٍ الدخول إلى الغابة...</p>
      </main>
    )
  }

  if (!user) return null

  return (
    <main className="min-h-screen px-4 py-6 max-w-7xl mx-auto">
      <Toast />

      {/* بطاقة غابتك */}
      <div className="bg-gradient-to-r from-emerald-900/70 via-green-900/50 to-emerald-950/70 rounded-2xl p-5 mb-6 border border-emerald-700/40 shadow-xl">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex-1 min-w-0">
            <p className="text-emerald-400/70 text-xs mb-1">غابتك الخاصة</p>
            <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center gap-2 flex-wrap">
              <span>🌲</span>
              <span className="truncate">{user.forestName || 'غابة بدون اسم'}</span>
              <button
                onClick={() => {
                  setIsFirstTime(false)
                  setShowRenameModal(true)
                }}
                className="text-xs bg-emerald-800/60 hover:bg-emerald-700/60 px-3 py-1.5 rounded-lg transition btn-press text-emerald-200"
              >
                ✏️ تعديل الاسم
              </button>
            </h1>
            <p className="text-emerald-300/50 text-sm mt-1">{user.displayName}</p>
          </div>
          <div className="text-left">
            <p className="text-xs text-emerald-400/60 mb-1">درجة الحرارة</p>
            <p className={`text-4xl sm:text-5xl font-bold ${TempColor(user.temperature)}`}>
              {user.temperature.toFixed(1)}°
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* شبكة الغابات */}
        <div className="flex-1">
          <h2 className="text-lg font-bold text-emerald-300 mb-4 flex items-center gap-2">
            <span>🌍</span> جميع الغابات ({forests.length})
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
            {forests.map((f) => (
              <ForestCard
                key={f.id}
                forest={f}
                isCurrentUser={f.id === user.id}
                myColdPoints={user.coldPoints}
                myHotPoints={user.hotPoints}
                onApplyPoints={handleApplyPoints}
              />
            ))}
          </div>
        </div>

        {/* الشريط الجانبي */}
        <div className="lg:w-72 flex-shrink-0">
          <UserSidebar coldPoints={user.coldPoints} hotPoints={user.hotPoints} />
        </div>
      </div>

      <RenameForestModal
        isOpen={showRenameModal}
        onClose={() => {
          if (isFirstTime && !user.forestName) {
            // لا يمكن إغلاقه في أول دخول بدون تسمية
            showToast('يجب تسمية غابتك للمتابعة', 'error')
            return
          }
          setShowRenameModal(false)
        }}
        onSave={handleRename}
        initialName={user.forestName || ''}
        isFirstTime={isFirstTime}
        defaultSuggestion={`غابة ${user.displayName}`}
      />
    </main>
  )
}
