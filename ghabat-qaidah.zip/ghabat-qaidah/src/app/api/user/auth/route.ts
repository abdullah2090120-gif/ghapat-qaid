import { NextResponse } from 'next/server'
import { VerifyUserAuth } from '@/lib/auth'
import { SetAuthCookie } from '@/lib/cookies'

export async function POST(request: Request) {
  const { token } = await request.json()

  const result = await VerifyUserAuth(token)

  if (!result.valid) {
    if (result.status === 'banned') {
      return NextResponse.json({ error: result.error, code: 'BANNED' }, { status: 403 })
    }
    return NextResponse.json({ error: result.error, code: 'INVALID' }, { status: 404 })
  }

  await SetAuthCookie({
    userId: result.user!.id,
    token: result.user!.accessToken,
    role: 'USER',
  })

  return NextResponse.json({
    success: true,
    user: {
      id: result.user!.id,
      displayName: result.user!.displayName,
      forestName: result.user!.forestName,
      temperature: result.user!.temperature,
      coldPoints: result.user!.coldPoints,
      hotPoints: result.user!.hotPoints,
    },
  })
}
