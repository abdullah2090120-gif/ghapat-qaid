'use client'

import { useState, useEffect } from 'react'

interface UserSidebarProps {
  coldPoints: number
  hotPoints: number
}

interface ActivityItem {
  id: string
  message: string
  time: string
}

export default function UserSidebar({ coldPoints, hotPoints }: UserSidebarProps) {
  const [activities, setActivities] = useState<ActivityItem[]>([])

  useEffect(() => {
    // جلب آخر 10 أحداث
    fetch('/api/user/activity')
      .then((r) => r.json())
      .then((data) => {
        if (data.activities) setActivities(data.activities)
      })
      .catch(() => {})
  }, [])

  return (
    <div className="space-y-4">
      {/* رصيد النقاط */}
      <div className="bg-emerald-950/60 border border-emerald-800/40 rounded-xl p-4">
        <h3 className="text-sm font-bold text-emerald-300 mb-3">رصيد نقاطي</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-cyan-950/50 border border-cyan-800/40 rounded-lg p-3 text-center">
            <div className="text-2xl mb-1">❄️</div>
            <div className="text-xl font-bold text-cyan-300">{coldPoints}</div>
            <div className="text-xs text-cyan-400/60">نقاط باردة</div>
          </div>
          <div className="bg-orange-950/50 border border-orange-800/40 rounded-lg p-3 text-center">
            <div className="text-2xl mb-1">🔥</div>
            <div className="text-xl font-bold text-orange-300">{hotPoints}</div>
            <div className="text-xs text-orange-400/60">نقاط ساخنة</div>
          </div>
        </div>
        <p className="text-xs text-emerald-400/50 mt-3 text-center">
          كل نقطة = 0.5 درجة مئوية
        </p>
      </div>

      {/* سجل النشاط */}
      <div className="bg-emerald-950/60 border border-emerald-800/40 rounded-xl p-4">
        <h3 className="text-sm font-bold text-emerald-300 mb-3">آخر الأحداث</h3>
        {activities.length === 0 ? (
          <p className="text-xs text-emerald-400/40 text-center py-4">
            لا توجد أحداث بعد
          </p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {activities.map((act) => (
              <div
                key={act.id}
                className="text-xs bg-black/30 rounded-lg px-3 py-2 border border-emerald-900/30"
              >
                <p className="text-emerald-100/80">{act.message}</p>
                <p className="text-emerald-500/40 mt-1">{act.time}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
