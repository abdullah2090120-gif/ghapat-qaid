import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { GetCurrentUser } from '@/lib/auth'

export async function GET() {
  const user = await GetCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
  }

  const actions = await prisma.action.findMany({
    where: {
      OR: [{ senderId: user.id }, { receiverId: user.id }],
    },
    include: {
      sender: { select: { displayName: true, forestName: true } },
      receiver: { select: { displayName: true, forestName: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 10,
  })

  const activities = actions.map((a) => {
    const senderName = a.sender.forestName || a.sender.displayName
    const receiverName = a.receiver.forestName || a.receiver.displayName
    let message = ''
    if (a.type === 'COLD') message = `${senderName} ألقى برودة ❄️ على ${receiverName}`
    else if (a.type === 'HOT') message = `${senderName} ألقى حرارة 🔥 على ${receiverName}`
    else if (a.type === 'HOST_GRANT') message = `المضيف منح نقاطاً لـ ${receiverName} 🎁`
    else if (a.type === 'RENAME_FOREST') message = `${senderName} غيّر اسم غابته ✨`

    return {
      id: a.id,
      message,
      time: new Date(a.createdAt).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
    }
  })

  return NextResponse.json({ activities })
}
