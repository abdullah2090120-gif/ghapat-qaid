import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function POST(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  await prisma.user.updateMany({
    where: { role: 'USER' },
    data: { temperature: 32 },
  })

  const { BroadcastUpdate } = await import('@/lib/realtime')
  BroadcastUpdate({ type: 'reset_all' })

  return NextResponse.json({ success: true })
}
