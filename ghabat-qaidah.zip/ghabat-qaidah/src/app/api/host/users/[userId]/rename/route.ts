import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'
import { ValidateForestName } from '@/lib/validators'

export async function POST(
  request: Request,
  { params }: { params: { userId: string } }
) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const { name } = await request.json()
  const validation = ValidateForestName(name)
  if (!validation.valid) {
    return NextResponse.json({ error: validation.error }, { status: 400 })
  }

  try {
    const updated = await prisma.user.update({
      where: { id: params.userId },
      data: { forestName: name.trim() },
    })

    await prisma.action.create({
      data: {
        senderId: auth.user!.id,
        receiverId: params.userId,
        type: 'RENAME_FOREST',
        amount: 0,
      },
    })

    const { BroadcastUpdate } = await import('@/lib/realtime')
    BroadcastUpdate({
      type: 'renamed',
      userId: params.userId,
      forestName: updated.forestName,
    })

    return NextResponse.json({ success: true, forestName: updated.forestName })
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'هذا الاسم مستخدم بالفعل' }, { status: 409 })
    }
    return NextResponse.json({ error: 'خطأ في الحفظ' }, { status: 500 })
  }
}
