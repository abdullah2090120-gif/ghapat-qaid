import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { GetCurrentUser } from '@/lib/auth'
import { Clamp, CheckRateLimit } from '@/lib/utils'

export async function POST(request: Request) {
  const user = await GetCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
  }

  // Rate limiting: 10 عمليات في الدقيقة
  const rate = CheckRateLimit(user.id, 10, 60)
  if (!rate.allowed) {
    return NextResponse.json(
      { error: `استخدمت كل العمليات المسموحة. حاول بعد ${rate.resetIn} ثانية` },
      { status: 429 }
    )
  }

  const { targetUserId, type, amount } = await request.json()

  if (!['COLD', 'HOT'].includes(type)) {
    return NextResponse.json({ error: 'نوع غير صالح' }, { status: 400 })
  }

  if (amount !== 0.5 && amount !== 1) {
    return NextResponse.json({ error: 'الكمية المسموحة: 0.5 أو 1 فقط' }, { status: 400 })
  }

  const pointsNeeded = Math.floor(amount * 2)
  const pointField = type === 'COLD' ? 'coldPoints' : 'hotPoints'
  const tempDelta = type === 'COLD' ? -amount : amount

  try {
    const result = await prisma.$transaction(async (tx) => {
      // تحقق من الرصيد
      const sender = await tx.user.findUnique({ where: { id: user.id } })
      if (!sender || sender[pointField] < pointsNeeded) {
        throw new Error('رصيد النقاط غير كافٍ')
      }

      // خصم النقاط
      const updatedSender = await tx.user.update({
        where: { id: user.id },
        data: { [pointField]: { decrement: pointsNeeded } },
      })

      // تحديث الحرارة
      const target = await tx.user.findUnique({ where: { id: targetUserId } })
      if (!target || target.role === 'HOST') {
        throw new Error('الغابة الهدف غير موجودة')
      }

      const newTemp = Clamp(target.temperature + tempDelta, 0, 100)

      const updatedTarget = await tx.user.update({
        where: { id: targetUserId },
        data: { temperature: newTemp },
      })

      // سجل العملية
      await tx.action.create({
        data: {
          senderId: user.id,
          receiverId: targetUserId,
          type: type as any,
          amount,
        },
      })

      return {
        newTemp,
        coldPoints: updatedSender.coldPoints,
        hotPoints: updatedSender.hotPoints,
        targetTemp: updatedTarget.temperature,
      }
    })

    // بث التحديثات
    const { BroadcastUpdate } = await import('@/lib/realtime')
    BroadcastUpdate({
      type: 'temperature_updated',
      userId: targetUserId,
      temperature: result.newTemp,
    })
    BroadcastUpdate({
      type: 'points_updated',
      userId: user.id,
      coldPoints: result.coldPoints,
      hotPoints: result.hotPoints,
    })

    return NextResponse.json({ success: true, ...result })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || 'حدث خطأ' }, { status: 400 })
  }
}
