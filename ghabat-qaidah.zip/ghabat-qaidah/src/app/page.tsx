export default function HomePage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <div className="max-w-md w-full">
        <div className="text-7xl mb-6">🌲</div>
        <h1 className="text-4xl font-bold text-emerald-300 mb-4">غابة قائدة</h1>
        <p className="text-lg text-emerald-100/80 mb-2">
          افتح الرابط الذي أعطاك إياه المضيف
        </p>
        <p className="text-sm text-emerald-400/50 mb-8">
          الرابط يبدو هكذا: /u/xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
        </p>
        <div className="bg-emerald-950/50 border border-emerald-800/50 rounded-xl p-4 text-sm text-emerald-300/70">
          <p>إذا كنت المضيف، ادخل عبر رابطك الخاص:</p>
          <code className="block mt-2 bg-black/40 px-3 py-2 rounded text-xs text-emerald-400 break-all">
            /host?key=المفتاح_السري
          </code>
        </div>
      </div>
    </main>
  )
}
