import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { SetAuthCookie } from '@/lib/cookies'
import { GenerateAccessToken } from '@/lib/utils'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const key = searchParams.get('key')
  const hostSecret = process.env.HOST_SECRET

  if (!hostSecret) {
    return NextResponse.json({ error: 'تكوين الخادم غير مكتمل' }, { status: 500 })
  }

  // تحقق من الكوكي أولاً
  const { GetAuthCookie } = await import('@/lib/cookies')
  const cookie = await GetAuthCookie()
  if (cookie && cookie.role === 'HOST') {
    const user = await prisma.user.findUnique({ where: { id: cookie.userId } })
    if (user && user.role === 'HOST' && !user.isBanned) {
      return NextResponse.json({ success: true })
    }
  }

  // تحقق من key
  if (!key || key !== hostSecret) {
    return NextResponse.json({ error: 'مفتاح غير صالح' }, { status: 401 })
  }

  // ابحث أو أنشئ مستخدم المضيف
  let hostUser = await prisma.user.findFirst({ where: { role: 'HOST' } })
  if (!hostUser) {
    hostUser = await prisma.user.create({
      data: {
        displayName: 'المضيف',
        forestName: 'مملكة الغابة',
        accessToken: GenerateAccessToken(),
        role: 'HOST',
      },
    })
  }

  await SetAuthCookie({
    userId: hostUser.id,
    token: hostUser.accessToken,
    role: 'HOST',
  })

  return NextResponse.json({ success: true })
}
