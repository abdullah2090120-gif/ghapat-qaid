export default function BannedPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <div className="max-w-md w-full">
        <div className="text-6xl mb-6">🚫</div>
        <h1 className="text-3xl font-bold text-red-400 mb-4">تم إيقافك</h1>
        <p className="text-gray-300">
          تم إيقاف وصولك إلى اللعبة من قبل المضيف.
        </p>
        <p className="text-sm text-gray-500 mt-4">
          تواصل مع المضيف إذا كنت تعتقد أن هذا خطأ.
        </p>
      </div>
    </main>
  )
}
