import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { GetCurrentUser } from '@/lib/auth'

export async function GET() {
  const user = await GetCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
  }

  const forests = await prisma.user.findMany({
    where: { role: 'USER' },
    orderBy: { createdAt: 'asc' },
    select: {
      id: true,
      displayName: true,
      forestName: true,
      temperature: true,
      coldPoints: true,
      hotPoints: true,
    },
  })

  return NextResponse.json({ forests })
}
