export interface ValidationResult {
  valid: boolean
  error?: string
}

/** التحقق من صحة اسم الغابة */
export function ValidateForestName(name: string): ValidationResult {
  if (!name || name.trim().length === 0) {
    return { valid: false, error: 'الاسم لا يمكن أن يكون فارغاً' }
  }

  const trimmed = name.trim()

  if (trimmed.length < 2) {
    return { valid: false, error: 'الاسم يجب أن يكون حرفين على الأقل' }
  }

  if (trimmed.length > 30) {
    return { valid: false, error: 'الاسم لا يمكن أن يتجاوز 30 حرفاً' }
  }

  // يسمح: حروف عربية وإنجليزية، أرقام، مسافات، شرطات، شرطات سفلية
  const validPattern = /^[\p{L}\p{N}\s\-_]+$/u
  if (!validPattern.test(trimmed)) {
    return { valid: false, error: 'الاسم يحتوي على رموز غير مسموحة (يُسمح فقط بحروف وأرقام ومسافات وشرطات)' }
  }

  return { valid: true }
}
