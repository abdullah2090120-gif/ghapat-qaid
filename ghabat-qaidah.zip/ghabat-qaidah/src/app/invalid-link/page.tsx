import Link from 'next/link'

export default function InvalidLinkPage() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 text-center">
      <div className="max-w-md w-full">
        <div className="text-6xl mb-6">⚠️</div>
        <h1 className="text-3xl font-bold text-amber-400 mb-4">الرابط غير صالح</h1>
        <p className="text-emerald-100/80 mb-2">
          قد يكون الرابط منتهي الصلاحية أو تم إبطاله من قبل المضيف.
        </p>
        <p className="text-sm text-emerald-400/50 mb-8">
          اطلب رابطاً جديداً من المضيف.
        </p>
        <Link
          href="/"
          className="inline-block px-6 py-3 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg transition btn-press"
        >
          العودة للصفحة الرئيسية
        </Link>
      </div>
    </main>
  )
}
