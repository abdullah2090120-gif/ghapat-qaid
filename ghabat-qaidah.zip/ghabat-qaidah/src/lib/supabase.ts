import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ''
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ''

/**
 * عميل Supabase للواجهة الأمامية — يستخدم فقط للـ Realtime (Broadcast).
 * قاعدة البيانات الفعلية تُدار عبر Prisma مباشرة.
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
})

export const REALTIME_CHANNEL = 'forest-updates'
export const REALTIME_EVENT = 'update'
