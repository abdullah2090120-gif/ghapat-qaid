import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'غابة قائدة 🌲',
  description: 'لعبة تفاعلية — كل لاعب يملك غابة خاصة ويتحكم بدرجة حرارتها',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="ar" dir="rtl">
      <body className="relative">
        {/* خلفية النجوم */}
        <div className="stars-bg" aria-hidden="true">
          {Array.from({ length: 50 }).map((_, i) => (
            <span
              key={i}
              className="star"
              style={{
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                width: `${Math.random() * 2 + 1}px`,
                height: `${Math.random() * 2 + 1}px`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${Math.random() * 3 + 2}s`,
              }}
            />
          ))}
        </div>
        <div className="relative z-10">{children}</div>
      </body>
    </html>
  )
}
