'use client'

import { useEffect } from 'react'
import { useStore } from '@/store/useStore'
import { cn } from '@/lib/utils'

export default function Toast() {
  const toast = useStore((s) => s.toast)
  const clearToast = useStore((s) => s.clearToast)

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(clearToast, 3500)
      return () => clearTimeout(timer)
    }
  }, [toast, clearToast])

  if (!toast) return null

  return (
    <div
      className={cn(
        'fixed top-4 left-1/2 -translate-x-1/2 z-[100] px-5 py-3 rounded-xl shadow-2xl text-sm font-medium border animate-pulse',
        toast.type === 'success' && 'bg-emerald-700/95 border-emerald-500 text-white',
        toast.type === 'error' && 'bg-red-700/95 border-red-500 text-white',
        toast.type === 'info' && 'bg-amber-700/95 border-amber-500 text-white'
      )}
    >
      {toast.message}
    </div>
  )
}
