import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** يولّد توكن وصول فريد بطول 48 حرفاً عشوائياً */
export function GenerateAccessToken(): string {
  const array = new Uint8Array(24)
  crypto.getRandomValues(array)
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('')
}

/** يقيد القيمة بين حد أدنى وأقصى */
export function Clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

/** يولّد سلسلة عشوائية بطول محدد */
export function RandomString(length: number): string {
  const array = new Uint8Array(length)
  crypto.getRandomValues(array)
  return Array.from(array, (byte) => byte.toString(16).padStart(2, '0')).join('').slice(0, length)
}

// ===== توقيع JWT بسيط باستخدام Web Crypto =====

const encoder = new TextEncoder()
const decoder = new TextDecoder()

async function getSigningKey(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    'raw',
    encoder.encode(secret),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign', 'verify']
  )
}

function base64UrlEncode(data: Uint8Array): string {
  const base64 = btoa(String.fromCharCode(...data))
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

function base64UrlDecode(str: string): Uint8Array {
  const base64 = str.replace(/-/g, '+').replace(/_/g, '/')
  const padded = base64 + '='.repeat((4 - (base64.length % 4)) % 4)
  return Uint8Array.from(atob(padded), (c) => c.charCodeAt(0))
}

function parseExpiresIn(expiresIn: string): number {
  const match = expiresIn.match(/^(\d+)([smhd])$/)
  if (!match) return 7 * 24 * 60 * 60 * 1000
  const num = parseInt(match[1])
  const units: Record<string, number> = { s: 1000, m: 60000, h: 3600000, d: 86400000 }
  return num * units[match[2]]
}

export async function SignJWT(payload: Record<string, unknown>, secret: string, expiresIn = '7d'): Promise<string> {
  const header = { alg: 'HS256', typ: 'JWT' }
  const fullPayload = {
    ...payload,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor((Date.now() + parseExpiresIn(expiresIn)) / 1000),
  }

  const headerB64 = base64UrlEncode(encoder.encode(JSON.stringify(header)))
  const payloadB64 = base64UrlEncode(encoder.encode(JSON.stringify(fullPayload)))
  const data = `${headerB64}.${payloadB64}`

  const key = await getSigningKey(secret)
  const signature = await crypto.subtle.sign('HMAC', key, encoder.encode(data))
  const sigB64 = base64UrlEncode(new Uint8Array(signature))

  return `${data}.${sigB64}`
}

export async function VerifyJWT<T = Record<string, unknown>>(token: string, secret: string): Promise<T> {
  const parts = token.split('.')
  if (parts.length !== 3) throw new Error('تنسيق التوكن غير صالح')

  const [headerB64, payloadB64, sigB64] = parts
  const data = `${headerB64}.${payloadB64}`

  const key = await getSigningKey(secret)
  const signature = base64UrlDecode(sigB64)
  const valid = await crypto.subtle.verify('HMAC', key, signature, encoder.encode(data))

  if (!valid) throw new Error('توقيع التوكن غير صالح')

  const payload = JSON.parse(decoder.decode(base64UrlDecode(payloadB64))) as { exp: number } & T
  if (payload.exp * 1000 < Date.now()) throw new Error('انتهت صلاحية الجلسة')

  return payload
}

// ===== Rate Limiting (ذاكرة محلية — كافية لـ 22 مستخدماً) =====

interface RateRecord {
  count: number
  resetAt: number
}

const rateStore = new Map<string, RateRecord>()

export function CheckRateLimit(
  identifier: string,
  limit = 10,
  windowSec = 60
): { allowed: boolean; remaining: number; resetIn: number } {
  const now = Date.now()
  let record = rateStore.get(identifier)

  if (!record || now > record.resetAt) {
    record = { count: 0, resetAt: now + windowSec * 1000 }
  }

  record.count++
  rateStore.set(identifier, record)

  const allowed = record.count <= limit
  return {
    allowed,
    remaining: Math.max(0, limit - record.count),
    resetIn: Math.ceil((record.resetAt - now) / 1000),
  }
}

/** يحدد لون درجة الحرارة */
export function TempColor(temp: number): string {
  if (temp <= 20) return 'text-cyan-400'
  if (temp <= 40) return 'text-emerald-300'
  if (temp <= 60) return 'text-amber-300'
  if (temp <= 80) return 'text-orange-400'
  return 'text-red-400'
}

export function TempBg(temp: number): string {
  if (temp <= 20) return 'from-cyan-900/40 to-blue-950/60'
  if (temp <= 40) return 'from-emerald-900/40 to-green-950/60'
  if (temp <= 60) return 'from-amber-900/40 to-yellow-950/60'
  if (temp <= 80) return 'from-orange-900/40 to-red-950/60'
  return 'from-red-900/40 to-rose-950/60'
}
