import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// حماية بسيطة — التحقق الفعلي يتم في كل API route على السيرفر
export function middleware(request: NextRequest) {
  return NextResponse.next()
}

export const config = {
  matcher: ['/api/:path*'],
}
