export type Role = 'HOST' | 'USER'
export type ActionType = 'COLD' | 'HOT' | 'HOST_GRANT' | 'RENAME_FOREST'

export interface UserPublic {
  id: string
  displayName: string
  forestName: string | null
  temperature: number
  coldPoints: number
  hotPoints: number
  isBanned: boolean
  lastSeenAt: string
  role: Role
}

export interface ForestUpdateEvent {
  type: 'temperature_updated' | 'renamed' | 'points_updated' | 'user_banned' | 'user_unbanned' | 'reset_all'
  userId?: string
  forestName?: string
  temperature?: number
  coldPoints?: number
  hotPoints?: number
  timestamp: number
}

export interface ActivityEntry {
  id: string
  senderName: string
  receiverName: string
  type: ActionType
  amount: number
  createdAt: string
}

export interface HostStats {
  onlineCount: number
  maxTemp: number
  minTemp: number
  avgTemp: number
  totalUsers: number
}
