# 🌲 غابة قائدة — دليل التشغيل السريع

## 🚀 النشر على الإنترنت (يعمل من الجوال مباشرة)

### الخطوة 1: أنشئ حسابات مجانية
1. افتح **github.com** وأنشئ حساباً
2. افتح **vercel.com** وسجّل بها باستخدام حساب GitHub
3. افتح **supabase.com** وأنشئ حساباً

### الخطوة 2: قاعدة البيانات (Supabase)
1. في Supabase → **New Project** → اسمه: `ghabat`
2. اختر كلمة مرور واحفظها
3. اختر المنطقة: **Frankfurt** (الأقرب)
4. انتظر دقيقتين حتى يجهز
5. اذهب إلى: **Settings ⚙️ → Database → Connection String → URI**
   - انسخ الرابط (يبدو: `postgresql://postgres:xxxx@db.xxxx.supabase.co:5432/postgres`)
   - **استبدل `[YOUR-PASSWORD]` بكلمة المرور التي اخترتها**
6. اذهب إلى: **Settings ⚙️ → API** وانسخ:
   - `Project URL` (مثل: `https://xxxx.supabase.co`)
   - `anon public` key (سلسلة طويلة تبدأ بـ `eyJ...`)

### الخطوة 3: ارفع الملفات إلى GitHub
1. في GitHub → **+ → New repository** → اسمه `ghabat-qaidah` → Public → Create
2. اضغط **uploading an existing file**
3. اسحب كل ملفات المشروع (الموجودة في هذا المجلد) وأفلتها
4. اضغط **Commit changes**

### الخطوة 4: النشر على Vercel
1. في Vercel → **Add New → Project**
2. اختر المستودع `ghabat-qaidah` → **Import**
3. في قسم **Environment Variables** أضف هذه المتغيرات (واحداً تلو الآخر):

| الاسم | القيمة |
|-------|--------|
| `DATABASE_URL` | رابط URI من Supabase (مع كلمة المرور) |
| `HOST_SECRET` | كلمة سر تختارها أنت (مثل: `ana-althabit-2025`) |
| `SESSION_SECRET` | سلسلة عشوائية طويلة (مثل: `abc123def456ghi789jkl012mno345pqr`) |
| `NEXT_PUBLIC_SUPABASE_URL` | Project URL من Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | anon key من Supabase |

4. اضغط **Deploy** وانتظر دقيقتين
5. 🎉 ستحصل على رابط مثل: `https://ghabat-qaidah-xxxx.vercel.app`

### الخطوة 5: الدخول كمالك (المضيف)
افتح في متصفح جوالك:
```
https://رابط-موقعك.vercel.app/host?key=كلمة_السر_التي_اخترتها
```

مثال:
```
https://ghabat-qaidah-abc123.vercel.app/host?key=ana-althabit-2025
```

✅ ستدخل لوحة التحكم → اضغط **"توليد الغابات"** → ستظهر 22 رابطاً → انسخها وأرسلها للناس!

---

## ⚠️ ملاحظات مهمة
- **لا تشارك رابط `/host?key=...` مع أحد** — فقط أنت
- الروابط التي تظهر في الجدول هي التي ترسلها لكل لاعب
- كل لاعب يفتح رابطه ويدخل مباشرة بدون تسجيل
- إذا أردت إيقاف شخص → اضغط زر 🚫 بجانب اسمه
- إذا تسرب رابط شخص → اضغط 🔄 لتوليد رابط جديد له

---

## 💻 التشغيل المحلي (على الكمبيوتر فقط)
```bash
npm install
npx prisma migrate dev --name init
npm run dev
```
ثم افتح: `http://localhost:3000/host?key=كلمة_السر`
