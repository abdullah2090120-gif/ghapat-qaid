import { NextResponse } from 'next/server'
import { GetCurrentUser } from '@/lib/auth'

export async function GET() {
  const user = await GetCurrentUser()
  if (!user) {
    return NextResponse.json({ error: 'غير مصرح' }, { status: 401 })
  }

  return NextResponse.json({
    user: {
      id: user.id,
      displayName: user.displayName,
      forestName: user.forestName,
      temperature: user.temperature,
      coldPoints: user.coldPoints,
      hotPoints: user.hotPoints,
    },
  })
}
