'use client'

import { useState, useEffect } from 'react'

interface RenameForestModalProps {
  isOpen: boolean
  onClose: () => void
  onSave: (name: string) => Promise<void>
  initialName?: string
  isFirstTime?: boolean
  defaultSuggestion?: string
}

export default function RenameForestModal({
  isOpen,
  onClose,
  onSave,
  initialName = '',
  isFirstTime = false,
  defaultSuggestion = '',
}: RenameForestModalProps) {
  const [name, setName] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isOpen) {
      setName(initialName || defaultSuggestion || '')
      setError('')
    }
  }, [isOpen, initialName, defaultSuggestion])

  if (!isOpen) return null

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')

    const trimmed = name.trim()
    if (!trimmed) {
      setError('الاسم لا يمكن أن يكون فارغاً')
      return
    }
    if (trimmed.length < 2) {
      setError('الاسم يجب أن يكون حرفين على الأقل')
      return
    }
    if (trimmed.length > 30) {
      setError('الاسم لا يمكن أن يتجاوز 30 حرفاً')
      return
    }

    setLoading(true)
    try {
      await onSave(trimmed)
      onClose()
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء حفظ الاسم')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gradient-to-b from-emerald-900 to-green-950 p-6 rounded-2xl shadow-2xl max-w-md w-full border border-emerald-700/50">
        <div className="text-center mb-4">
          <div className="text-4xl mb-2">{isFirstTime ? '🌲' : '✏️'}</div>
          <h2 className="text-2xl font-bold text-white">
            {isFirstTime ? 'سمّ غابتك' : 'تعديل اسم الغابة'}
          </h2>
          {isFirstTime && (
            <p className="text-emerald-300 text-sm mt-2">
              اختر اسماً مميزاً لغابتك الخاصة — سيظهر للجميع
            </p>
          )}
        </div>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="اكتب اسم الغابة هنا..."
            maxLength={30}
            className="w-full px-4 py-3 rounded-xl bg-black/40 border border-emerald-600/50 text-white placeholder-emerald-500/50 focus:border-emerald-400 focus:ring-2 focus:ring-emerald-500/30 transition mb-2 text-center text-lg"
            autoFocus
            disabled={loading}
          />

          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-emerald-400/60">{name.length}/30</span>
          </div>

          {error && (
            <p className="text-red-400 text-sm mb-3 bg-red-950/40 px-3 py-2 rounded-lg border border-red-800/40">
              {error}
            </p>
          )}

          <p className="text-xs text-emerald-400/50 mb-4 text-center">
            يُسمح: حروف عربية وإنجليزية، أرقام، مسافات، شرطات
          </p>

          <div className="flex gap-3">
            {!isFirstTime && (
              <button
                type="button"
                onClick={onClose}
                disabled={loading}
                className="flex-1 py-3 px-4 rounded-xl bg-gray-700/60 text-white hover:bg-gray-600/60 transition btn-press disabled:opacity-50"
              >
                إلغاء
              </button>
            )}
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-3 px-4 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-500 transition btn-press disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'جارٍ الحفظ...' : isFirstTime ? 'ابدأ اللعب 🎉' : 'حفظ الاسم'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
