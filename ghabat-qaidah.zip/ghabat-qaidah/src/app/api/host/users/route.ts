import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function GET(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const users = await prisma.user.findMany({
    where: { role: 'USER' },
    orderBy: { createdAt: 'asc' },
  })

  const now = Date.now()
  const usersWithStatus = users.map((u) => ({
    id: u.id,
    displayName: u.displayName,
    forestName: u.forestName,
    accessToken: u.accessToken,
    temperature: u.temperature,
    coldPoints: u.coldPoints,
    hotPoints: u.hotPoints,
    isBanned: u.isBanned,
    lastSeenAt: u.lastSeenAt.toISOString(),
    online: now - u.lastSeenAt.getTime() < 30000, // متصل إذا ظهر خلال آخر 30 ثانية
  }))

  return NextResponse.json({ users: usersWithStatus })
}
