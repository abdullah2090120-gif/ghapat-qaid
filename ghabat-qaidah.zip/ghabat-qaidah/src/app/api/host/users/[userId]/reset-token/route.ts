import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'
import { GenerateAccessToken } from '@/lib/utils'

export async function POST(
  request: Request,
  { params }: { params: { userId: string } }
) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const newToken = GenerateAccessToken()

  const updated = await prisma.user.update({
    where: { id: params.userId },
    data: { accessToken: newToken },
  })

  return NextResponse.json({ success: true, accessToken: updated.accessToken })
}
