'use client'

import { create } from 'zustand'
import type { UserPublic, ForestUpdateEvent } from '@/types'

interface AppState {
  currentUser: UserPublic | null
  forests: UserPublic[]
  toast: { message: string; type: 'success' | 'error' | 'info' } | null
  setCurrentUser: (user: UserPublic | null) => void
  setForests: (forests: UserPublic[]) => void
  applyEvent: (event: ForestUpdateEvent) => void
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void
  clearToast: () => void
}

export const useStore = create<AppState>((set, get) => ({
  currentUser: null,
  forests: [],
  toast: null,

  setCurrentUser: (user) => set({ currentUser: user }),

  setForests: (forests) => set({ forests }),

  applyEvent: (event) => {
    const { forests, currentUser } = get()

    if (event.type === 'reset_all') {
      set({
        forests: forests.map((f) => ({ ...f, temperature: 32 })),
        currentUser: currentUser ? { ...currentUser, temperature: 32 } : null,
      })
      return
    }

    if (!event.userId) return

    set({
      forests: forests.map((f) => {
        if (f.id !== event.userId) return f
        return {
          ...f,
          ...(event.temperature !== undefined && { temperature: event.temperature }),
          ...(event.forestName !== undefined && { forestName: event.forestName }),
          ...(event.coldPoints !== undefined && { coldPoints: event.coldPoints }),
          ...(event.hotPoints !== undefined && { hotPoints: event.hotPoints }),
        }
      }),
      currentUser:
        currentUser && currentUser.id === event.userId
          ? {
              ...currentUser,
              ...(event.temperature !== undefined && { temperature: event.temperature }),
              ...(event.forestName !== undefined && { forestName: event.forestName }),
              ...(event.coldPoints !== undefined && { coldPoints: event.coldPoints }),
              ...(event.hotPoints !== undefined && { hotPoints: event.hotPoints }),
            }
          : currentUser,
    })
  },

  showToast: (message, type = 'info') => set({ toast: { message, type } }),
  clearToast: () => set({ toast: null }),
}))
