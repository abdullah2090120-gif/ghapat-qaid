import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function GET(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const users = await prisma.user.findMany({
    where: { role: 'USER' },
    select: { temperature: true, lastSeenAt: true },
  })

  if (users.length === 0) {
    return NextResponse.json({
      stats: { onlineCount: 0, maxTemp: 0, minTemp: 0, avgTemp: 0, totalUsers: 0 },
    })
  }

  const temps = users.map((u) => u.temperature)
  const now = Date.now()
  const onlineCount = users.filter((u) => now - u.lastSeenAt.getTime() < 30000).length

  const stats = {
    onlineCount,
    maxTemp: Math.max(...temps),
    minTemp: Math.min(...temps),
    avgTemp: temps.reduce((a, b) => a + b, 0) / temps.length,
    totalUsers: users.length,
  }

  return NextResponse.json({ stats })
}
