import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'
import { GenerateAccessToken } from '@/lib/utils'

export async function POST(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const existingCount = await prisma.user.count({ where: { role: 'USER' } })
  if (existingCount > 0) {
    return NextResponse.json(
      { error: 'المستخدمون موجودون بالفعل. لا يمكن التوليد مرة أخرى.' },
      { status: 400 }
    )
  }

  const users = []
  for (let i = 1; i <= 22; i++) {
    const user = await prisma.user.create({
      data: {
        displayName: `Player ${i}`,
        accessToken: GenerateAccessToken(),
        forestName: null,
      },
    })
    users.push(user)
  }

  return NextResponse.json({ success: true, count: users.length })
}
