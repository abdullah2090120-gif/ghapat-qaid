import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'
import type { ForestUpdateEvent } from '@/types'

/**
 * بث تحديث لحظي لجميع المتصلين عبر Supabase Realtime Broadcast.
 * هذا المسار يُستدعى من الخادم بعد كل عملية ناجحة.
 */
export async function POST(request: Request) {
  const event = (await request.json()) as ForestUpdateEvent

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

  if (!supabaseUrl || !supabaseKey) {
    return NextResponse.json({ error: 'إعدادات Supabase مفقودة' }, { status: 500 })
  }

  const supabase = createClient(supabaseUrl, supabaseKey)

  const { error } = await supabase.channel('forest-updates').send({
    type: 'broadcast',
    event: 'update',
    payload: event,
  })

  if (error) {
    console.error('[Broadcast] خطأ:', error)
    return NextResponse.json({ error: 'فشل البث' }, { status: 500 })
  }

  return NextResponse.json({ success: true })
}
