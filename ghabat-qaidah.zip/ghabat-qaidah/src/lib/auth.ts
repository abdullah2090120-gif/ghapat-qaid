import prisma from './prisma'
import { GetAuthCookie } from './cookies'

export interface AuthResult {
  valid: boolean
  error?: string
  user?: {
    id: string
    displayName: string
    forestName: string | null
    role: 'HOST' | 'USER'
    isBanned: boolean
  }
}

/** التحقق من صلاحية المضيف — إما عبر الكوكي أو عبر key في الرابط */
export async function VerifyHostAuth(request?: Request): Promise<AuthResult> {
  const hostSecret = process.env.HOST_SECRET
  if (!hostSecret) {
    return { valid: false, error: 'تكوين الخادم غير مكتمل — HOST_SECRET مفقود' }
  }

  // 1) تحقق من الكوكي أولاً
  const cookie = await GetAuthCookie()
  if (cookie && cookie.role === 'HOST') {
    const user = await prisma.user.findUnique({ where: { id: cookie.userId } })
    if (user && user.role === 'HOST' && !user.isBanned) {
      return { valid: true, user }
    }
  }

  // 2) تحقق من key في الرابط
  if (request) {
    const { searchParams } = new URL(request.url)
    const key = searchParams.get('key')
    if (key && key === hostSecret) {
      // ابحث عن مستخدم المضيف أو أنشئه
      let hostUser = await prisma.user.findFirst({ where: { role: 'HOST' } })
      if (!hostUser) {
        const { GenerateAccessToken } = await import('./utils')
        hostUser = await prisma.user.create({
          data: {
            displayName: 'المضيف',
            forestName: 'مملكة الغابة',
            accessToken: GenerateAccessToken(),
            role: 'HOST',
          },
        })
      }
      return { valid: true, user: hostUser }
    }
  }

  return { valid: false, error: 'غير مصرح لك بالوصول إلى لوحة المضيف' }
}

export interface UserAuthResult {
  valid: boolean
  error?: string
  status?: 'invalid' | 'banned'
  user?: {
    id: string
    displayName: string
    forestName: string | null
    accessToken: string
    role: 'HOST' | 'USER'
    temperature: number
    coldPoints: number
    hotPoints: number
    isBanned: boolean
  }
}

/** التحقق من صلاحية مستخدم عبر توكن الوصول */
export async function VerifyUserAuth(token: string): Promise<UserAuthResult> {
  if (!token || token.length !== 48) {
    return { valid: false, error: 'الرابط غير صالح', status: 'invalid' }
  }

  const user = await prisma.user.findUnique({ where: { accessToken: token } })

  if (!user) {
    return { valid: false, error: 'الرابط غير صالح أو تم إبطاله', status: 'invalid' }
  }

  if (user.isBanned) {
    return { valid: false, error: 'تم إيقافك من قبل المضيف', status: 'banned' }
  }

  // تحديث آخر ظهور
  await prisma.user.update({
    where: { id: user.id },
    data: { lastSeenAt: new Date() },
  })

  return { valid: true, user }
}

/** التحقق من المستخدم الحالي عبر الكوكي (لعمليات API) */
export async function GetCurrentUser() {
  const cookie = await GetAuthCookie()
  if (!cookie) return null

  const user = await prisma.user.findUnique({ where: { id: cookie.userId } })
  if (!user || user.isBanned) return null

  return user
}
