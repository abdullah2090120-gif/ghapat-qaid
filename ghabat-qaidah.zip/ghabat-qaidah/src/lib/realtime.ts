'use client'

import { supabase, REALTIME_CHANNEL, REALTIME_EVENT } from './supabase'
import type { ForestUpdateEvent } from '@/types'

export type { ForestUpdateEvent }

/**
 * الاشتراك في تحديثات الغابات اللحظية.
 * يرجع دالة تنظيف لإلغاء الاشتراك.
 */
export function SubscribeToForestUpdates(
  callback: (event: ForestUpdateEvent) => void
): () => void {
  const channel = supabase.channel(REALTIME_CHANNEL)

  channel
    .on(
      'broadcast',
      { event: REALTIME_EVENT },
      (payload: { payload: ForestUpdateEvent }) => {
        callback(payload.payload)
      }
    )
    .subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log('[Realtime] متصل بالتحديثات اللحظية')
      } else if (status === 'CHANNEL_ERROR') {
        console.warn('[Realtime] خطأ في الاتصال — سيتم إعادة المحاولة تلقائياً')
      }
    })

  return () => {
    supabase.removeChannel(channel)
  }
}

/**
 * إرسال حدث تحديث عبر قناة Broadcast (من الواجهة الأمامية).
 * في الواقع نستدعي API route على السيرفر ليقوم بالإرسال.
 */
export async function BroadcastUpdate(event: Omit<ForestUpdateEvent, 'timestamp'>): Promise<void> {
  try {
    await fetch('/api/broadcast', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...event, timestamp: Date.now() }),
    })
  } catch (e) {
    console.error('[Broadcast] فشل إرسال التحديث:', e)
  }
}
