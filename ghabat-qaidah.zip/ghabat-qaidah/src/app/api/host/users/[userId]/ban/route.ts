import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function POST(
  request: Request,
  { params }: { params: { userId: string } }
) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const { banned } = await request.json()

  const updated = await prisma.user.update({
    where: { id: params.userId },
    data: { isBanned: banned },
  })

  const { BroadcastUpdate } = await import('@/lib/realtime')
  BroadcastUpdate({
    type: banned ? 'user_banned' : 'user_unbanned',
    userId: params.userId,
  })

  return NextResponse.json({ success: true, isBanned: updated.isBanned })
}
