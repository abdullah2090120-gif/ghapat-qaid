'use client'

import { useState } from 'react'
import { cn, TempColor, TempBg } from '@/lib/utils'

interface ForestCardProps {
  forest: {
    id: string
    displayName: string
    forestName: string | null
    temperature: number
  }
  isCurrentUser: boolean
  myColdPoints: number
  myHotPoints: number
  onApplyPoints: (targetUserId: string, type: 'COLD' | 'HOT', amount: number) => Promise<void>
}

export default function ForestCard({
  forest,
  isCurrentUser,
  myColdPoints,
  myHotPoints,
  onApplyPoints,
}: ForestCardProps) {
  const [loading, setLoading] = useState<'COLD' | 'HOT' | null>(null)

  const handleClick = async (type: 'COLD' | 'HOT') => {
    if (loading) return
    setLoading(type)
    try {
      await onApplyPoints(forest.id, type, 0.5)
    } finally {
      setLoading(null)
    }
  }

  const canCold = myColdPoints >= 1
  const canHot = myHotPoints >= 1

  return (
    <div
      className={cn(
        'relative rounded-xl p-4 border transition-all duration-300 bg-gradient-to-br',
        TempBg(forest.temperature),
        isCurrentUser
          ? 'border-emerald-400/70 ring-2 ring-emerald-400/30'
          : 'border-emerald-800/40 hover:border-emerald-600/60'
      )}
    >
      {isCurrentUser && (
        <span className="absolute -top-2 -right-2 bg-emerald-500 text-white text-xs px-2 py-0.5 rounded-full font-bold">
          غابتي
        </span>
      )}

      <div className="mb-3">
        <h3 className="font-bold text-white text-base leading-tight truncate">
          {forest.forestName || 'غابة بدون اسم'}
        </h3>
        <p className="text-xs text-emerald-300/60 truncate">{forest.displayName}</p>
      </div>

      <div className={cn('text-2xl font-bold mb-3', TempColor(forest.temperature))}>
        {forest.temperature.toFixed(1)}°C
      </div>

      <div className="flex gap-2">
        <button
          onClick={() => handleClick('COLD')}
          disabled={!canCold || loading !== null}
          title={`نقطة باردة (رصيدك: ${myColdPoints})`}
          className={cn(
            'flex-1 py-2 rounded-lg text-sm font-bold transition btn-press',
            canCold
              ? 'bg-cyan-600/80 hover:bg-cyan-500 text-white'
              : 'bg-gray-700/40 text-gray-500 cursor-not-allowed'
          )}
        >
          {loading === 'COLD' ? '...' : '❄️'}
        </button>
        <button
          onClick={() => handleClick('HOT')}
          disabled={!canHot || loading !== null}
          title={`نقطة ساخنة (رصيدك: ${myHotPoints})`}
          className={cn(
            'flex-1 py-2 rounded-lg text-sm font-bold transition btn-press',
            canHot
              ? 'bg-orange-600/80 hover:bg-orange-500 text-white'
              : 'bg-gray-700/40 text-gray-500 cursor-not-allowed'
          )}
        >
          {loading === 'HOT' ? '...' : '🔥'}
        </button>
      </div>
    </div>
  )
}
