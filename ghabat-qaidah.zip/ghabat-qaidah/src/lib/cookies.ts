import { cookies } from 'next/headers'
import { SignJWT, VerifyJWT } from './utils'

const COOKIE_NAME = 'ghabat_session'

const COOKIE_OPTIONS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
  sameSite: 'lax' as const,
  maxAge: 60 * 60 * 24 * 7, // 7 أيام
  path: '/',
}

export interface SessionPayload {
  userId: string
  token: string
  role: 'HOST' | 'USER'
}

export async function SetAuthCookie(payload: SessionPayload): Promise<void> {
  const secret = process.env.SESSION_SECRET
  if (!secret) throw new Error('SESSION_SECRET غير مُعرّف في متغيرات البيئة')

  const signed = await SignJWT(payload, secret, '7d')
  cookies().set(COOKIE_NAME, signed, COOKIE_OPTIONS)
}

export async function GetAuthCookie(): Promise<SessionPayload | null> {
  const secret = process.env.SESSION_SECRET
  if (!secret) return null

  const session = cookies().get(COOKIE_NAME)?.value
  if (!session) return null

  try {
    const decoded = await VerifyJWT<SessionPayload>(session, secret)
    return {
      userId: decoded.userId,
      token: decoded.token,
      role: decoded.role,
    }
  } catch {
    return null
  }
}

export function ClearAuthCookie(): void {
  cookies().set(COOKIE_NAME, '', { ...COOKIE_OPTIONS, maxAge: 0 })
}
