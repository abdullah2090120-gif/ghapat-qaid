import { NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { VerifyHostAuth } from '@/lib/auth'

export async function POST(request: Request) {
  const auth = await VerifyHostAuth(request)
  if (!auth.valid) {
    return NextResponse.json({ error: auth.error }, { status: 401 })
  }

  const { userId, type, amount } = await request.json()

  if (!['COLD', 'HOT'].includes(type)) {
    return NextResponse.json({ error: 'نوع غير صالح' }, { status: 400 })
  }

  if (amount !== 0.5 && amount !== 1) {
    return NextResponse.json({ error: 'الكمية المسموحة: 0.5 أو 1 فقط' }, { status: 400 })
  }

  const pointsToAdd = Math.floor(amount * 2) // 0.5 = نقطة واحدة، 1 = نقطتان
  const field = type === 'COLD' ? 'coldPoints' : 'hotPoints'

  const target = await prisma.user.findUnique({ where: { id: userId } })
  if (!target) {
    return NextResponse.json({ error: 'المستخدم غير موجود' }, { status: 404 })
  }

  const updated = await prisma.user.update({
    where: { id: userId },
    data: { [field]: { increment: pointsToAdd } },
  })

  // سجل العملية
  await prisma.action.create({
    data: {
      senderId: auth.user!.id,
      receiverId: userId,
      type: 'HOST_GRANT',
      amount,
    },
  })

  // بث التحديث
  const { BroadcastUpdate } = await import('@/lib/realtime')
  BroadcastUpdate({
    type: 'points_updated',
    userId,
    coldPoints: updated.coldPoints,
    hotPoints: updated.hotPoints,
  })

  return NextResponse.json({ success: true, coldPoints: updated.coldPoints, hotPoints: updated.hotPoints })
}
